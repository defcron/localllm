#!/usr/bin/env python3
import json
import subprocess
from pathlib import Path
root = Path(__file__).resolve().parents[1]
cpp = root / "app/src/main/cpp"
paths = [cpp / "llama.cpp"] + [path.parent for path in sorted((cpp / "vendor").glob("*/.git"))]
commits = {str(path.relative_to(root)): subprocess.check_output(["git", "-C", str(path), "rev-parse", "HEAD"], text=True).strip() for path in paths}
lock = root / "native-dependencies.lock.json"
if lock.exists() and json.loads(lock.read_text()) != commits:
    raise SystemExit("Dependency revisions differ from native-dependencies.lock.json. Restore the recorded commits or consciously remove the lock to regenerate it.")
lock.write_text(json.dumps(commits, indent=2) + "\n")
