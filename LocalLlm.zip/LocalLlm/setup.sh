#!/usr/bin/env bash
# Pulls llama.cpp into the NDK build. Pin to a release tag once everything builds.
set -e
git clone --depth 1 https://github.com/ggml-org/llama.cpp app/src/main/cpp/llama.cpp
