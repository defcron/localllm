# Validation and provenance

Base: the original uploaded LocalLlm.zip.txt, with the GPU/MCP/CI changes from
this conversation applied directly. This is a regenerated complete deliverable,
not a verified byte-for-byte mirror of a fetched GitHub snapshot. Unrelated
changes you may have made only in your repository are not claimed to be merged.

Executed successfully in this turn:

- 12 host unittest cases, including compiled/executed production GPU policy
  helpers and typed OpenCL dispatch against representative MOCK headers/driver.
- GLSLC provisioner tests with mock compiler output, invalid-path and invalid-
  SPIR-V rejection. These did not download the real SDK or compile real shaders.
- 30 source wiring checks: GPU defaults/device/layers, optional driver behavior,
  full MCP schemas/pagination/aliases, JNI entry points, SDK versions, applied
  CMake resolver, CI host provisioning/ordering, and archive-relative script paths.
- Python source compilation, shell syntax, workflow YAML parsing, and compilation
  of the workflow's embedded safe ZIP-extraction script.
- Final outer/inner ZIP CRC checks, safe paths, executable mode preservation,
  preservation of original project file names, and byte-for-byte equality of the
  ready-to-upload archive's source with the unpacked project.

Included but NOT executed:

- 16 Kotlin/JUnit tests for settings, tool catalogs/schemas/aliases, JSON/SSE
  pagination, cursor cycles, and routing through mock MCP servers.

NOT verified here:

- LunarG SDK downloading/extraction or real host glslc compilation.
- Android/CMake/Gradle build against downloaded native dependencies.
- APK installation and Vulkan/OpenCL behavior on Samsung Galaxy S25 Ultra.

The editing environment has no Android SDK/NDK, JDK, Gradle, CMake, real glslc,
or upstream native dependency checkout. Therefore the archive is not a compiled
APK and must not be described as a passed Android CI build. The updated workflow
performs that build on your GitHub runner.

Native sources: llama.cpp v0.6.0; Khronos headers cloned on initial setup with
resolved revisions written to a lock file. Host shader SDK is latest official
Linux release unless repository variable VULKAN_SDK_VERSION is set. Downloads
use official HTTPS endpoints; SDK signature/checksum verification beyond HTTPS
is not claimed. Gradle distribution SHA-256 is explicitly verified.
