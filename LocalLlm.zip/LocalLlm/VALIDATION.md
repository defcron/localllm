# Validation status

## Executed here — passed

- 7 host Python unittest cases, including C++17 compilation and execution of
  production GpuPolicy helpers and generated OpenCL dispatch against a MOCK
  OpenCL header/vendor library. These are not Qualcomm-driver/device tests.
- 23 automated source-wiring checks, including JNI entry points, Vulkan/OpenCL
  flags, explicit device/layer propagation, optional OpenCL declaration, native
  loading API, reload UI, MCP pagination/routing, and full-schema prompt output.
- Shell syntax checks for setup.sh and gradlew.
- Python compilation checks for all included tooling.
- ZIP CRC, safe relative paths, original file preservation, executable shell
  permissions, and byte-for-byte matching of archive entries to final source.

## Not executed here

- Native Android/CMake configuration or compilation against fetched dependencies.
- Gradle Android build, Kotlin/JUnit tests, or APK installation.
- Vulkan/OpenCL model loading or performance on a Samsung Galaxy S25 Ultra.

The editing environment has no JDK, Gradle, CMake, Android SDK/NDK, shader compiler,
or native dependency checkout. Dependency downloads are performed by setup.sh
on the build machine. Accordingly, this artifact must not be described as an
Android-build-verified or device-tested application. The generated dispatcher
was host-tested with representative declarations, not every fetched Khronos
header declaration; the real generated source is compiled during the Android build.

## Build-machine checks

    ./setup.sh
    python3 -m unittest discover -s tools/tests -v
    ./gradlew :app:testDebugUnitTest
    ./gradlew :app:assembleDebug

The upstream API preflight intentionally stops setup if the native API does not
match the pinned source. Keep the selected revision and inspect that mismatch;
do not silently switch native versions or remove safety checks.

## Device acceptance

1. Start with a small supported quantized GGUF, Vulkan, -ngl 99, context 4096.
2. Confirm Active identifies Vulkan/device and actual offload count if the
   loader reports one. Unknown actual count remains explicitly marked unknown.
3. Send a cold prompt, then a short follow-up; record cached/new input and tok/s.
4. Select OpenCL and reload; confirm the reported backend changes. Verify that
   an inaccessible driver causes an error instead of CPU-only generation.
5. Test -ngl 0: Active should explicitly identify CPU. Return to 99 and reload.
6. Stop generation, adjust backend/layers, reload, restart the app, and confirm
   saved settings and cached model reuse.
7. Check GPU-memory/context errors on a too-large model; lower context/layers
   rather than expecting the app to infer a device-wide safe maximum.
8. Connect a MCP server exposing >6000 characters of tool signatures. Verify
   N/N inclusion and call a late-listed tool. Test overlapping tool names on
   two servers, refresh after adding tools, then remove servers.
