# Local LLM for Android — Vulkan / OpenCL / complete MCP tools

This source project targets Android API 36, min API 31, arm64-v8a.
Vulkan is the default backend. Setup can select OpenCL (Adreno) and configure
GPU layers (`-ngl`), default 99. Changes are saved immediately and take effect
when the model is reloaded. `-1` requests all layers; `0` explicitly requests CPU.

## Build

Prerequisites: Android SDK API 36, a recent Android NDK, SDK CMake 3.31.6,
JDK 17, Git, Python 3, curl, unzip, and a recent HOST `glslc` from Vulkan SDK.
Set `GLSLC` to its absolute executable path if it is not on PATH. Host `glslc`
compiles shaders; it is not an Android executable. Windows users can prepare
dependencies using Git Bash/Python and build using Android Studio.

    ./setup.sh
    ./gradlew :app:testDebugUnitTest
    ./gradlew :app:assembleDebug

Open the project in Android Studio to install/run on a real arm64 phone.
The included `gradlew` is a checksum-verified Gradle 8.13 source bootstrap,
not a standard wrapper requiring an omitted JAR. It downloads Gradle on first
use. `setup.sh` fetches llama.cpp v0.6.0 and Khronos headers, generates a typed
OpenCL vendor dispatcher, and records dependency commits in a lock file.
Downloaded native dependencies and GGUF model weights are not bundled.

## Run

1. Setup: leave Vulkan selected and GPU layers at 99 initially.
2. Pick a compatible GGUF. The first selection imports one copy into private
   app storage. Subsequent Reload model operations reuse that file.
3. Read Active in Setup: backend, device, requested layers, and the loader's
   actual offload count when available. Requested count is not actual count.
4. To compare OpenCL, select it and press Reload model / apply settings.
5. Configure MCP servers. Every discovered tool and original input schema is
   included; use Refresh all tools after server-side catalog changes.

## Important limits

- This ZIP is SOURCE, not a compiled or device-tested APK.
- 99 is a high offload request, not an S25 Ultra memory-fit guarantee. Model
  size/quantization/context determine fit. Reduce layers or context on failure.
- GPU backends may still execute unsupported operations on CPU. GPU selection
  does not mean every operation can run on GPU. No CPU-only backend fallback
  is performed automatically after a GPU load failure.
- OpenCL requires Samsung/Qualcomm's `libOpenCL.so` to be exposed to the app's
  Android linker namespace. An optional manifest declaration requests access.
  No vendor driver is copied into the APK. Inaccessible drivers produce an error.
- The dynamically loaded vendor driver is optional: the JNI library has no
  mandatory ELF dependency on libOpenCL.so, so Vulkan remains independently usable.
- F16 KV and auto Flash Attention are compatibility defaults; F16 KV uses more
  memory than the original Q8_0 setting. Compatibility retry disables Flash
  Attention but keeps the same selected GPU.
- A first model import requires additional disk space approximately equal to
  that GGUF. Native loading still uses mmap. Selecting the file again reimports
  it; Reload model reuses the cached import. This uses public upstream path APIs
  instead of relying on the original FILE* loader integration.
- Full tool catalogs may exceed context. Tools are never silently omitted.
  Increase Context size and reload, or configure fewer servers.
- Tool calling uses Hermes/Qwen `<tool_call>` JSON; model templates must be
  supported by llama.cpp. MCP supports Streamable HTTP, not direct stdio.

See CHANGES.md and VALIDATION.md for exact changes and what was tested.
