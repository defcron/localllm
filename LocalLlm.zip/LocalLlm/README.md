# Local LLM (Android 16 / API 36, arm64)

Compose chat UI -> Kotlin tool loop -> JNI -> llama.cpp, plus an MCP client (Streamable HTTP).

## Build
1. Android Studio (latest) + SDK Manager: NDK (Side by side) and CMake 3.22.1
2. `./setup.sh`   (clones llama.cpp into app/src/main/cpp/llama.cpp)
3. Open this folder in Android Studio, accept the Gradle/AGP upgrade assistant if it offers one, Run on a real arm64 phone (not an emulator).
4. Put a .gguf on the phone (try a Qwen2.5/Qwen3 3B-4B Instruct, Q4_0 or Q4_K_M), Setup -> Pick & load.
5. Setup -> add an MCP server URL (e.g. https://host/mcp). Tools show up in the system prompt automatically.

## Efficiency tricks baked in
- mmap'd weights, loaded straight from the picked file's fd (no copy)
- KV-cache prefix reuse: only new tokens get prefilled each turn (stable system prompt = warm cache)
- Q8_0 KV cache + flash attention (falls back to f16 automatically)
- threads pinned to the fast cores only; dotprod NEON kernels
- tool outputs truncated to 4000 chars; token UI updates throttled to ~25/s

## Known limits
- Tool calling uses the Hermes/Qwen `<tool_call>` JSON format: best with Qwen2.5/3, Hermes, etc.
- Chat templates must be ones llama.cpp's built-in matcher knows (else you get an error bubble).
- MCP: Streamable HTTP only. stdio servers need a stdio->HTTP bridge (e.g. in Termux).
- Context overflow drops the oldest exchange (no KV shifting yet).
- Versions in build.gradle.kts are placeholders; bump to current.
