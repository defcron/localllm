# Changes relative to the uploaded LocalLlm.zip.txt

## GPU integration

- Added GpuSettings/GpuBackend with Vulkan and -ngl 99 defaults, persistent
  SharedPreferences, input validation, -1/all and 0/explicit CPU handling.
- Added Setup radio buttons, GPU-layer input, active backend/device reporting,
  pending-settings notice, and reload/apply button. Controls cannot alter a
  running generation or load; Send is blocked during model loading/reconnection.
- JNI receives the selected backend and layer count. It selects that backend's
  device, including integrated GPUs when supported by the upstream API, and
  sets llama_model_params.devices and n_gpu_layers.
- Both GGML_VULKAN and GGML_OPENCL compile into the same JNI library. Automatic
  backend plugin loading is disabled to keep selection explicit.
- Added a generated, typed OpenCL dispatcher forwarding core cl.h APIs directly
  to the runtime vendor libOpenCL.so. Static linking and hidden archive symbols
  avoid making that optional vendor driver an ELF startup dependency or exposing
  forwarding symbols for accidental driver interposition. Vulkan links Android's
  system Vulkan loader independently.
- OpenCL missing-driver/missing-symbol behavior returns OpenCL errors instead
  of fake success. OpenCL driver accessibility and backend GPU availability are
  checked. Zero offloaded layers, when reported, are rejected for nonzero -ngl.
- No automatic backend change to CPU on GPU error. mmap-to-normal loading and
  Flash-Attention compatibility retries keep the same selected GPU settings.
- F16 KV + auto Flash Attention favor backend compatibility. Some unsupported
  operations may use CPU inside a GPU-backed graph; this is not CPU-only fallback.

## Build and model loading

- Upgraded the requested SDK CMake version from 3.22.1 to 3.31.6 (minimum 3.29).
- Added native dependency bootstrap, host shader-compiler discovery, Khronos
  C/C++ header preparation, upstream API preflight, and dependency revision lock.
  llama.cpp is pinned to v0.6.0. Khronos repositories are cloned from main on
  first setup and their exact commits recorded; subsequent setup does not update
  them automatically and checks the lock.
- Added a source-only Gradle 8.13 bootstrap with official-distribution SHA-256
  verification rather than depending on a missing wrapper JAR.
- Added private-storage GGUF import once and cache reuse on reload, using
  llama_model_load_from_file and mmap. This removes the assumption that every
  SAF provider supplies a seekable descriptor or that a custom FILE* API exists.
  First import takes disk space and time; it is not part of steady-state prefill.

## MCP fixes retained

- Removed the 6000-character tool-signature cutoff and schema slimming.
- Every discovered tool, full description, and unchanged input schema is emitted.
- Same-named tools from separate servers use non-shadowing aliases and route to
  the correct server with the original wire-level tool name.
- Preserved pagination including empty opaque cursor strings; added cycle and
  within-server duplicate guards and atomic catalog publication.
- Added Refresh all tools and included/available counts; cached prompt is rebuilt
  on refresh. Automatic tool-list-change subscription is not implemented.
- Context overflow reports that tools were retained rather than hiding them.

## Prefill diagnostics

- Preserved KV prefix reuse and optimized native Release configuration.
- Stats now distinguish cached/new input tokens and show uncached prefill tok/s.
- UI streaming mutations are dispatched to Main rather than updating Compose
  state directly from the native inference worker.

## Tests

- Seven executable host tests: parser/dispatcher generation, callback forwarding,
  pointer/error fallback generation, compiled native policy checks, compiled
  typed dispatch to a mock vendor library and missing-symbol behavior.
- Sixteen Kotlin/JUnit regressions: GPU defaults/persistence/validation, complete
  tool prompts/schema retention, namespace collisions, JSON/SSE pagination,
  cycle rejection, and end-to-end routing via two mock MCP servers.
