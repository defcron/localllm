# MCP tool visibility fix

## Root cause in the supplied project

ChatViewModel.systemPrompt() imposed TOOL_BUDGET_CHARS = 6000 and broke out
of the tool loop when the next signature exceeded the budget. Any tools after
that point were never shown to the LLM. A single large first tool could hide
all tools. McpHub separately discarded tools with names already used by an
other server (first server wins).

The original McpClient already followed tools/list pagination. Pagination was
not the primary bug.

The schema slimming function also removed schema keywords such as
additionalProperties and default, and truncated descriptions. Those changes
could discard validation/argument guidance. The replacement preserves the
complete original schema, including property names and definition maps.

## Changes

- ToolPrompt builds a deterministic full catalog: every tool, complete description,
  and unmodified inputSchema. There is no character-budget cutoff.
- ToolRegistry preserves unique tool names. If multiple servers expose the same
  name, each gets a distinct alias such as mcp_s1__search / mcp_s2__search.
  Alias allocation avoids shadowing real tool names. The prefix refers to the
  configured server's 1-based position; aliases may change if servers are reordered
  or a name becomes unique. Descriptions identify the server and original name.
- McpHub routes each alias to its originating client and ORIGINAL wire-level name.
  A mutex serializes reconnects/calls, and complete catalogs are published atomically.
  Cancellation cannot publish a partially connected replacement catalog.
- Pagination retains opaque cursor values, including empty strings, consumes
  every page, and detects repeated cursors rather than looping forever. Invalid
  tool records and duplicate names within a single server fail explicitly.
- Setup reports included/available counts, adds Refresh all tools, and blocks
  server configuration changes while reconnecting/generating and blocks sending
  while a reconnect is in progress. Changing servers/refreshing invalidates the cached prompt.
- Context overflow never strips the tool catalog. Old chat history may be removed
  by the existing retry logic; if that is insufficient, a visible error explains
  that all tools were retained and that the context must be increased.

## Context tradeoff

This patch deliberately includes every tool directly, rather than offering a
subset selected by a heuristic or hiding schemas behind a discovery tool.
Large catalogs therefore cost more prefill time and require more context/RAM.
The default 4096-token context is not guaranteed to fit a large server catalog.
The Setup control supports up to 32768 tokens; the usable limit also depends on
model and device resources. Change Context size, then reload the GGUF so that
llama.cpp actually allocates the new context. If the full catalog cannot fit on
the device, use fewer configured servers. This patch does not implement an
on-demand tool-discovery protocol or guarantee that a model will select a tool
correctly merely because its signature is present.

A failed server is reported in status; only successfully connected servers
contribute tools. Tool-list-change notifications are not automatically subscribed
to. Use Refresh all tools after a live server adds/removes tools.

## Regression tests included

12 JUnit tests in app/src/test/java/dev/localllm:

- ToolPromptTest: 150 tools beyond the old cutoff; one oversized tool plus a
  following tool; complete schemas including collision-prone property names,
  constraints, and references; deterministic/empty prompt output.
- ToolRegistryTest: unchanged unique names; duplicate names across servers;
  real-name/alias collisions; deterministic/empty registry output.
- McpClientTest: all JSON pages and all SSE pages (including an empty cursor);
  repeated-cursor errors without publishing a partial list; end-to-end alias
  routing through two mock MCP servers and clearing the catalog on refresh.

With Android SDK/NDK, JDK 17, Gradle compatible with the existing AGP version,
and the existing setup.sh prerequisites installed:

    ./setup.sh
    gradle :app:testDebugUnitTest
    gradle :app:assembleDebug

The supplied archive contains gradle-wrapper.properties but not gradlew,
gradlew.bat, or gradle-wrapper.jar. Use Android Studio/installed Gradle, or
generate a wrapper locally. This patch does not provide a compiled APK, vendor
llama.cpp, or change the original native llama.cpp integration/build versions.

## Verification performed in the editing environment

- Inspected the uploaded ZIP's Kotlin and native source.
- Passed automated source-level invariants for removal of the tool cutoff,
  full-schema serialization, alias routing, pagination, UI refresh/count wiring,
  and presence of all 12 Kotlin regression tests.
- Verified unchanged native/model-engine files against the original archive.
- Verified ZIP CRCs, paths, and preservation of original project files.

These are source/packaging checks, NOT a Kotlin compile or runtime test pass.
This environment has no JDK, Kotlin compiler, Gradle, Android SDK/NDK, or local
llama.cpp checkout, so the Android build and JUnit tests have not been run.

## Manual acceptance on a device

1. Build/install the app and load your tool-capable GGUF.
2. Connect a server exposing a tool catalog larger than 6000 characters.
3. Setup should display N / N tools included; start a new chat and request an
   operation that uses a tool late in that catalog.
4. If a context error appears, increase Context size, reload the model, and retry.
5. Connect two servers with a same-named tool. Ask for each server's operation;
   the catalog should contain distinct aliases and route them independently.
6. Add a tool to the server, press Refresh all tools, and check the new count/tool.
7. Remove all servers and verify the displayed count returns to 0 / 0.
