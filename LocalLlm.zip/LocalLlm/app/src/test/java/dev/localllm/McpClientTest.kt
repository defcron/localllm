package dev.localllm

import kotlinx.coroutines.runBlocking
import kotlinx.serialization.json.*
import okhttp3.mockwebserver.Dispatcher
import okhttp3.mockwebserver.MockResponse
import okhttp3.mockwebserver.MockWebServer
import okhttp3.mockwebserver.RecordedRequest
import org.junit.Assert.*
import org.junit.Test
import java.util.concurrent.CopyOnWriteArrayList

class McpClientTest {
    private fun tool(name: String) = buildJsonObject {
        put("name", name)
        put("description", "Description of $name")
        put("inputSchema", buildJsonObject { put("type", "object") })
    }
    private fun page(names: List<String>, cursor: String? = null) = buildJsonObject {
        put("tools", JsonArray(names.map { tool(it) }))
        if (cursor != null) put("nextCursor", cursor)
    }
    private fun response(id: JsonElement, result: JsonObject, sse: Boolean): MockResponse {
        val body = buildJsonObject { put("jsonrpc", "2.0"); put("id", id); put("result", result) }
        return if (sse) MockResponse().setHeader("Content-Type", "text/event-stream")
            .setBody("event: message\ndata: $body\n\n")
        else MockResponse().setHeader("Content-Type", "application/json").setBody(body.toString())
    }
    private fun configure(
        server: MockWebServer,
        seen: MutableList<JsonObject>,
        sse: Boolean = false,
        result: (JsonObject) -> JsonObject
    ) {
        server.dispatcher = object : Dispatcher() {
            override fun dispatch(request: RecordedRequest): MockResponse {
                val rpc = Json.parseToJsonElement(request.body.readUtf8()).jsonObject
                seen += rpc
                return when (rpc["method"]!!.jsonPrimitive.content) {
                    "initialize" -> response(rpc["id"]!!, buildJsonObject {
                        put("protocolVersion", McpClient.PROTOCOL)
                        put("capabilities", buildJsonObject { put("tools", buildJsonObject {}) })
                        put("serverInfo", buildJsonObject { put("name", "test"); put("version", "1") })
                    }, sse).setHeader("Mcp-Session-Id", "test-session")
                    "notifications/initialized" -> MockResponse().setResponseCode(202)
                    else -> response(rpc["id"]!!, result(rpc), sse)
                }
            }
        }
        server.start()
    }

    private fun checkPagination(sse: Boolean) = runBlocking {
        MockWebServer().use { server ->
            val seen = CopyOnWriteArrayList<JsonObject>()
            configure(server, seen, sse) { rpc ->
                val cursor = rpc["params"]?.jsonObject?.get("cursor")?.jsonPrimitive?.content
                when (cursor) {
                    null -> page((0 until 50).map { "tool_$it" }, "")
                    "" -> page((50 until 100).map { "tool_$it" }, "opaque+/=cursor")
                    "opaque+/=cursor" -> page((100 until 150).map { "tool_$it" })
                    else -> error("Unexpected cursor")
                }
            }
            val client = McpClient(server.url("/mcp").toString(), null)
            client.connect()
            assertEquals((0 until 150).map { "tool_$it" }, client.tools.map { it.name })
            val lists = seen.filter { it["method"]!!.jsonPrimitive.content == "tools/list" }
            assertEquals(3, lists.size)
            assertNull(lists[0]["params"])
            assertEquals("", lists[1]["params"]!!.jsonObject["cursor"]!!.jsonPrimitive.content)
            assertEquals("opaque+/=cursor", lists[2]["params"]!!.jsonObject["cursor"]!!.jsonPrimitive.content)
            val prompt = ToolPrompt.build(client.tools)
            assertTrue(prompt.length > 6000)
            assertTrue(prompt.contains("\"name\":\"tool_149\""))
        }
    }

    @Test fun followsAllJsonPagesIncludingEmptyOpaqueCursor() { checkPagination(false) }
    @Test fun followsAllSsePagesIncludingEmptyOpaqueCursor() { checkPagination(true) }

    @Test fun repeatedCursorFailsWithoutPublishingPartialCatalog() = runBlocking {
        MockWebServer().use { server ->
            val seen = CopyOnWriteArrayList<JsonObject>()
            configure(server, seen) { rpc ->
                if (rpc["params"] == null) page(listOf("first"), "same") else page(listOf("second"), "same")
            }
            val client = McpClient(server.url("/mcp").toString(), null)
            var failure: Exception? = null
            try { client.connect() } catch (e: IllegalStateException) { failure = e }
            assertTrue(failure?.message.orEmpty().contains("repeated a pagination cursor"))
            assertTrue(client.tools.isEmpty())
        }
    }

    @Test fun aliasCallsCorrectServerUsingOriginalWireNameAndRefreshClearsTools() = runBlocking {
        MockWebServer().use { one -> MockWebServer().use { two ->
            val seenOne = CopyOnWriteArrayList<JsonObject>()
            val seenTwo = CopyOnWriteArrayList<JsonObject>()
            fun results(label: String, rpc: JsonObject): JsonObject =
                if (rpc["method"]!!.jsonPrimitive.content == "tools/list") page(listOf("search"))
                else buildJsonObject {
                    put("content", buildJsonArray { add(buildJsonObject { put("type", "text"); put("text", label) }) })
                }
            configure(one, seenOne) { results("one", it) }
            configure(two, seenTwo) { results("two", it) }
            val hub = McpHub()
            assertTrue(hub.connect(listOf(ServerCfg(one.url("/mcp").toString()), ServerCfg(two.url("/mcp").toString()))).isEmpty())
            assertEquals(2, hub.tools.size)
            val args = buildJsonObject { put("query", "hello") }
            assertEquals("one", hub.call("mcp_s1__search", args))
            assertEquals("two", hub.call("mcp_s2__search", args))
            for (seen in listOf(seenOne, seenTwo)) {
                val params = seen.single { it["method"]!!.jsonPrimitive.content == "tools/call" }["params"]!!.jsonObject
                assertEquals("search", params["name"]!!.jsonPrimitive.content)
                assertEquals(args, params["arguments"])
            }
            hub.connect(emptyList())
            assertTrue(hub.tools.isEmpty())
            assertTrue(hub.call("mcp_s1__search", args).startsWith("ERROR: unknown tool"))
        } }
    }
}
