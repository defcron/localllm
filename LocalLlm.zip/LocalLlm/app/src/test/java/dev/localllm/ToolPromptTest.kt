package dev.localllm

import kotlinx.serialization.json.*
import org.junit.Assert.*
import org.junit.Test

class ToolPromptTest {
    private fun functions(prompt: String): List<JsonObject> =
        prompt.substringAfter("<tools>\n").substringBefore("\n</tools>")
            .lines().map { Json.parseToJsonElement(it).jsonObject["function"]!!.jsonObject }

    @Test fun catalogBeyondOldBudgetIncludesEveryTool() {
        val tools = (0 until 150).map {
            McpTool("tool_$it", "Description ".repeat(25), buildJsonObject { put("type", "object") })
        }
        val prompt = ToolPrompt.build(tools)
        assertTrue(prompt.length > 6000)
        assertEquals(tools.map { it.name }, functions(prompt).map { it["name"]!!.jsonPrimitive.content })
    }

    @Test fun singleOversizedToolAndFollowingToolAreBothIncluded() {
        val tools = listOf(
            McpTool("huge", "x".repeat(8000), JsonObject(emptyMap())),
            McpTool("last", "last tool", JsonObject(emptyMap()))
        )
        assertEquals(listOf("huge", "last"), functions(ToolPrompt.build(tools)).map {
            it["name"]!!.jsonPrimitive.content
        })
        assertEquals(tools[0].description, functions(ToolPrompt.build(tools))[0]["description"]!!.jsonPrimitive.content)
    }

    @Test fun preservesSchemaIncludingPropertyNamesAndValidationKeywords() {
        val schema = Json.parseToJsonElement("""
            {"${'$'}schema":"https://json-schema.org/draft/2020-12/schema",
             "type":"object","additionalProperties":false,"required":["title","default"],
             "properties":{"title":{"type":"string","description":"${"long ".repeat(80)}"},
                           "default":{"type":"integer","default":7},
                           "examples":{"type":"array","items":{"type":"string"}},
                           "additionalProperties":{"type":"boolean"}},
             "${'$'}defs":{"id":{"type":"integer","minimum":1}},
             "allOf":[{"properties":{"id":{"${'$'}ref":"#/${'$'}defs/id"}}}]}
        """).jsonObject
        val f = functions(ToolPrompt.build(listOf(McpTool("schema_tool", "description", schema)))).single()
        assertEquals(schema, f["parameters"])
    }

    @Test fun deterministicAndEmptyCatalogHasNoStaleTools() {
        val tools = listOf(McpTool("one", "one", JsonObject(emptyMap())))
        assertEquals(ToolPrompt.build(tools), ToolPrompt.build(tools))
        assertFalse(ToolPrompt.build(emptyList()).contains("<tools>"))
    }
}
