package dev.localllm

import kotlinx.serialization.json.JsonObject
import org.junit.Assert.*
import org.junit.Test

class ToolRegistryTest {
    private fun tool(name: String) = McpTool(name, "Original description", JsonObject(emptyMap()))

    @Test fun uniqueNamesRemainUnchanged() {
        val bindings = ToolRegistry.build(listOf(ToolSource(0, "https://one/mcp", listOf(tool("read")))))
        assertEquals("read", bindings.single().tool.name)
        assertEquals("read", bindings.single().originalName)
    }

    @Test fun conflictingNamesExposeBothServersWithProvenance() {
        val bindings = ToolRegistry.build(listOf(
            ToolSource(0, "https://one/mcp", listOf(tool("search"))),
            ToolSource(1, "https://two/mcp", listOf(tool("search")))
        ))
        assertEquals(listOf("mcp_s1__search", "mcp_s2__search"), bindings.map { it.tool.name })
        assertEquals(listOf(0, 1), bindings.map { it.serverIndex })
        assertEquals(listOf("search", "search"), bindings.map { it.originalName })
        assertTrue(bindings[1].tool.description.contains("https://two/mcp"))
    }

    @Test fun generatedAliasCannotShadowARealTool() {
        val bindings = ToolRegistry.build(listOf(
            ToolSource(0, "https://one/mcp", listOf(tool("search"), tool("mcp_s1__search"))),
            ToolSource(1, "https://two/mcp", listOf(tool("search")))
        ))
        assertEquals(3, bindings.map { it.tool.name }.toSet().size)
        assertEquals("mcp_s1__search_2", bindings.first().tool.name)
        assertEquals("mcp_s1__search", bindings[1].tool.name)
    }

    @Test fun deterministicRebuildAndEmptyRegistry() {
        val sources = listOf(ToolSource(0, "https://one/mcp", listOf(tool("a"), tool("b"))))
        assertEquals(ToolRegistry.build(sources).map { it.tool.name }, ToolRegistry.build(sources).map { it.tool.name })
        assertTrue(ToolRegistry.build(emptyList()).isEmpty())
    }
}
