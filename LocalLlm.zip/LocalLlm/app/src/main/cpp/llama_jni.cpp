// Thin JNI layer over llama.cpp. All strings cross the boundary as UTF-8 byte[]
// (JNI "modified UTF-8" mangles emoji, and token pieces can split a character).
#include <jni.h>
#include <android/log.h>
#include <algorithm>
#include <atomic>
#include <cstdio>
#include <unistd.h>
#include <string>
#include <vector>
#include "llama.h"

#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, "LocalLlm", __VA_ARGS__)

namespace {
llama_model*   g_model = nullptr;
llama_context* g_ctx   = nullptr;
std::vector<llama_token> g_cache;      // tokens currently held in the KV cache
std::atomic<bool> g_cancel{false};
int g_n_ctx = 0;
std::string g_err;                     // last llama.cpp error lines, shown in the UI

const int N_BATCH = 512;

std::string to_str(JNIEnv* env, jbyteArray a) {
    jsize n = env->GetArrayLength(a);
    std::string s(n, '\0');
    env->GetByteArrayRegion(a, 0, n, reinterpret_cast<jbyte*>(s.data()));
    return s;
}
jbyteArray to_jbytes(JNIEnv* env, const char* p, size_t n) {
    jbyteArray a = env->NewByteArray((jsize) n);
    env->SetByteArrayRegion(a, 0, (jsize) n, reinterpret_cast<const jbyte*>(p));
    return a;
}
void free_all() {
    if (g_ctx)   llama_free(g_ctx);
    if (g_model) llama_model_free(g_model);
    g_ctx = nullptr; g_model = nullptr; g_cache.clear();
}
void log_cb(ggml_log_level level, const char* text, void*) {
    __android_log_print(level == GGML_LOG_LEVEL_ERROR ? ANDROID_LOG_ERROR : ANDROID_LOG_INFO, "llama", "%s", text);
    if (level == GGML_LOG_LEVEL_ERROR) {
        g_err += text;
        if (g_err.size() > 500) g_err.erase(0, g_err.size() - 500);
    }
}
}  // namespace

// Loads from an already-open fd (from the Storage Access Framework). Reopening via
// /proc/self/fd/N or a path is blocked by scoped storage, so we hand llama.cpp a FILE* instead.
// Returns "" on success, else an error message.
extern "C" JNIEXPORT jstring JNICALL
Java_dev_localllm_LlamaEngine_nativeLoad(JNIEnv* env, jobject, jint fd, jint nCtx, jint nThreads) {
    static bool inited = false;
    if (!inited) { llama_backend_init(); llama_log_set(log_cb, nullptr); inited = true; }
    free_all();
    g_err.clear();

    int d = dup(fd);                          // our own fd; the Kotlin side may close its copy
    FILE* f = d >= 0 ? fdopen(d, "rb") : nullptr;
    if (!f) return env->NewStringUTF("could not open the model file descriptor");
    // note: f is intentionally never fclose'd (one fd per load); mmap'd weights stay valid either way

    llama_model_params mp = llama_model_default_params();
    mp.load_mode = LLAMA_LOAD_MODE_MMAP;      // weights paged in lazily, no 2x RAM spike
    g_model = llama_model_load_from_file_ptr(f, mp);
    if (!g_model) {
        mp.load_mode = LLAMA_LOAD_MODE_NONE;  // retry without mmap (e.g. unaligned data offset)
        rewind(f);
        g_model = llama_model_load_from_file_ptr(f, mp);
    }
    if (!g_model) return env->NewStringUTF(g_err.empty() ? "model load failed (is it a valid .gguf / supported architecture / enough RAM?)" : g_err.c_str());

    llama_context_params cp = llama_context_default_params();
    cp.n_ctx = nCtx; cp.n_batch = N_BATCH; cp.n_ubatch = N_BATCH;
    cp.n_threads = nThreads; cp.n_threads_batch = nThreads;
    cp.flash_attn_type = LLAMA_FLASH_ATTN_TYPE_ENABLED;
    cp.type_k = GGML_TYPE_Q8_0; cp.type_v = GGML_TYPE_Q8_0;    // halves KV RAM
    g_ctx = llama_init_from_model(g_model, cp);
    if (!g_ctx) {                                              // fallback: plain f16 KV
        cp.type_k = GGML_TYPE_F16; cp.type_v = GGML_TYPE_F16;
        g_ctx = llama_init_from_model(g_model, cp);
    }
    if (!g_ctx) {
        std::string e = g_err.empty() ? "context creation failed (try a smaller context size)" : g_err;
        free_all();
        return env->NewStringUTF(e.c_str());
    }
    g_n_ctx = (int) llama_n_ctx(g_ctx);
    return env->NewStringUTF("");
}

extern "C" JNIEXPORT jbyteArray JNICALL
Java_dev_localllm_LlamaEngine_nativeApplyTemplate(JNIEnv* env, jobject, jobjectArray roles, jobjectArray contents) {
    if (!g_model) return to_jbytes(env, "", 0);
    const jsize n = env->GetArrayLength(roles);
    std::vector<std::string> rs(n), cs(n);
    std::vector<llama_chat_message> msgs(n);
    size_t est = 1024;
    for (jsize i = 0; i < n; i++) {
        auto jr = (jstring) env->GetObjectArrayElement(roles, i);
        const char* r = env->GetStringUTFChars(jr, nullptr);
        rs[i] = r;
        env->ReleaseStringUTFChars(jr, r);
        env->DeleteLocalRef(jr);
        auto jc = (jbyteArray) env->GetObjectArrayElement(contents, i);
        cs[i] = to_str(env, jc);
        env->DeleteLocalRef(jc);
        msgs[i] = { rs[i].c_str(), cs[i].c_str() };
        est += cs[i].size() * 2 + 64;
    }
    const char* tmpl = llama_model_chat_template(g_model, nullptr);
    if (!tmpl) tmpl = "chatml";
    std::string out(est, '\0');
    int len = llama_chat_apply_template(tmpl, msgs.data(), msgs.size(), true, out.data(), (int) out.size());
    if (len > (int) out.size()) {
        out.resize(len);
        len = llama_chat_apply_template(tmpl, msgs.data(), msgs.size(), true, out.data(), (int) out.size());
    }
    if (len < 0) len = 0;                     // template unsupported -> Kotlin shows an error
    return to_jbytes(env, out.data(), (size_t) len);
}

// Returns tokens generated, -1 on error, -2 if the prompt doesn't fit the context.
extern "C" JNIEXPORT jint JNICALL
Java_dev_localllm_LlamaEngine_nativeGenerate(JNIEnv* env, jobject, jbyteArray jprompt, jint maxNew, jfloat temp, jobject sink) {
    if (!g_model || !g_ctx) return -1;
    g_cancel = false;

    const llama_vocab* vocab = llama_model_get_vocab(g_model);
    std::string prompt = to_str(env, jprompt);

    int need = -llama_tokenize(vocab, prompt.c_str(), (int) prompt.size(), nullptr, 0, true, true);
    if (need <= 0) return -1;
    std::vector<llama_token> toks(need);
    if (llama_tokenize(vocab, prompt.c_str(), (int) prompt.size(), toks.data(), need, true, true) < 0) return -1;
    // chat templates often emit BOS themselves; don't double it
    if (toks.size() > 1 && toks[0] == llama_vocab_bos(vocab) && toks[1] == toks[0]) toks.erase(toks.begin());

    if ((int) toks.size() >= g_n_ctx - 16) return -2;
    maxNew = std::min<int>(maxNew, g_n_ctx - (int) toks.size() - 1);

    // --- KV cache reuse: only decode the part of the prompt we haven't seen ---
    llama_memory_t mem = llama_get_memory(g_ctx);
    size_t common = 0;
    while (common < g_cache.size() && common < toks.size() && g_cache[common] == toks[common]) common++;
    if (common == toks.size()) common--;      // need at least one fresh token to get logits
    if (!llama_memory_seq_rm(mem, 0, (llama_pos) common, -1)) {   // e.g. recurrent models can't trim
        llama_memory_clear(mem, true);
        common = 0;
    }
    g_cache.resize(common);

    for (size_t i = common; i < toks.size(); i += N_BATCH) {
        if (g_cancel) return 0;
        int cnt = (int) std::min<size_t>(N_BATCH, toks.size() - i);
        llama_batch b = llama_batch_get_one(toks.data() + i, cnt);
        if (llama_decode(g_ctx, b) != 0) {
            llama_memory_clear(mem, true); g_cache.clear();
            return -1;
        }
        g_cache.insert(g_cache.end(), toks.begin() + i, toks.begin() + i + cnt);
    }

    // --- sampling ---
    llama_sampler* smpl = llama_sampler_chain_init(llama_sampler_chain_default_params());
    if (temp <= 0.f) {
        llama_sampler_chain_add(smpl, llama_sampler_init_greedy());
    } else {
        llama_sampler_chain_add(smpl, llama_sampler_init_top_k(40));
        llama_sampler_chain_add(smpl, llama_sampler_init_top_p(0.9f, 1));
        llama_sampler_chain_add(smpl, llama_sampler_init_min_p(0.05f, 1));
        llama_sampler_chain_add(smpl, llama_sampler_init_temp(temp));
        llama_sampler_chain_add(smpl, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));
    }

    jclass cls = env->GetObjectClass(sink);
    jmethodID onToken = env->GetMethodID(cls, "onToken", "([B)Z");

    int produced = 0;
    while (produced < maxNew && !g_cancel) {
        llama_token t = llama_sampler_sample(smpl, g_ctx, -1);
        if (llama_vocab_is_eog(vocab, t)) break;

        char buf[256];
        int n = llama_token_to_piece(vocab, t, buf, sizeof(buf), 0, true);
        if (n < 0) n = 0;
        jbyteArray arr = to_jbytes(env, buf, (size_t) n);
        jboolean cont = env->CallBooleanMethod(sink, onToken, arr);
        env->DeleteLocalRef(arr);
        if (env->ExceptionCheck()) { env->ExceptionClear(); break; }

        llama_batch b = llama_batch_get_one(&t, 1);
        if (llama_decode(g_ctx, b) != 0) break;
        g_cache.push_back(t);
        produced++;
        if (!cont) break;
    }
    llama_sampler_free(smpl);
    return produced;
}

extern "C" JNIEXPORT void JNICALL
Java_dev_localllm_LlamaEngine_nativeCancel(JNIEnv*, jobject) { g_cancel = true; }

extern "C" JNIEXPORT void JNICALL
Java_dev_localllm_LlamaEngine_nativeFree(JNIEnv*, jobject) { free_all(); }
