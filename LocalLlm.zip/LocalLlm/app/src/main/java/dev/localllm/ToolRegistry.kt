package dev.localllm

/** Each exposed name maps back to a server and its original wire-level name. */
internal data class ToolSource(val serverIndex: Int, val url: String, val tools: List<McpTool>)
internal data class ToolBinding(val tool: McpTool, val serverIndex: Int, val originalName: String)

internal object ToolRegistry {
    fun build(sources: List<ToolSource>): List<ToolBinding> {
        val counts = sources.flatMap { it.tools }.groupingBy { it.name }.eachCount()
        val used = counts.filterValues { it == 1 }.keys.toMutableSet()
        return sources.flatMap { source ->
            source.tools.map { original ->
                val name = if (counts.getValue(original.name) == 1) original.name else {
                    val suffix = original.name.replace(Regex("[^A-Za-z0-9_-]"), "_").take(40)
                    val base = "mcp_s${source.serverIndex + 1}__$suffix"
                    var candidate = base
                    var n = 2
                    while (!used.add(candidate)) candidate = "${base}_${n++}"
                    candidate
                }
                ToolBinding(
                    McpTool(name, "MCP server ${source.serverIndex + 1} (${source.url}), tool ${original.name}.\n" +
                        original.description, original.schema),
                    source.serverIndex, original.name
                )
            }
        }
    }
}
