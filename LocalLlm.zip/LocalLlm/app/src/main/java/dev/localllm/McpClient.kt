package dev.localllm

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.Response
import okio.BufferedSource
import java.util.concurrent.TimeUnit

@Serializable
data class ServerCfg(val url: String, val token: String = "")

class McpTool(val name: String, val description: String, val schema: JsonObject)

/** Minimal MCP client for the Streamable HTTP transport (JSON or SSE replies, session ids, bearer auth). */
class McpClient(private val url: String, private val bearer: String?) {
    companion object {
        const val PROTOCOL = "2025-06-18"
        private val http = OkHttpClient.Builder()
            .connectTimeout(10, TimeUnit.SECONDS).readTimeout(120, TimeUnit.SECONDS).build()
        private val JSON_MT = "application/json".toMediaType()
    }

    private var session: String? = null
    private var negotiated: String? = null
    private var nextId = 1
    var tools: List<McpTool> = emptyList(); private set

    suspend fun connect() {
        val init = rpc("initialize", buildJsonObject {
            put("protocolVersion", PROTOCOL)
            put("capabilities", buildJsonObject {})
            put("clientInfo", buildJsonObject { put("name", "local-llm-android"); put("version", "0.1") })
        }).jsonObject
        negotiated = init["protocolVersion"]?.jsonPrimitive?.contentOrNull ?: PROTOCOL
        notify("notifications/initialized")

        val all = mutableListOf<McpTool>()
        var cursor: String? = null
        do {
            val r = rpc("tools/list", cursor?.let { c -> buildJsonObject { put("cursor", c) } }).jsonObject
            r["tools"]?.jsonArray?.forEach { t ->
                val o = t.jsonObject
                all += McpTool(
                    o["name"]!!.jsonPrimitive.content,
                    o["description"]?.jsonPrimitive?.contentOrNull ?: "",
                    o["inputSchema"]?.jsonObject ?: JsonObject(emptyMap())
                )
            }
            cursor = r["nextCursor"]?.jsonPrimitive?.contentOrNull
        } while (cursor != null)
        tools = all
    }

    suspend fun callTool(name: String, args: JsonObject): String {
        val r = rpc("tools/call", buildJsonObject { put("name", name); put("arguments", args) }).jsonObject
        val text = r["content"]?.jsonArray?.joinToString("\n") { c ->
            val o = c.jsonObject
            val type = o["type"]?.jsonPrimitive?.contentOrNull
            if (type == "text") o["text"]?.jsonPrimitive?.contentOrNull ?: "" else "[$type content omitted]"
        } ?: r.toString()
        val out = if (r["isError"]?.jsonPrimitive?.booleanOrNull == true) "ERROR: $text" else text
        // small models drown in big tool outputs; keep the context lean
        return if (out.length > 4000) out.take(4000) + "\n…[truncated]" else out
    }

    private suspend fun rpc(method: String, params: JsonObject?): JsonElement = withContext(Dispatchers.IO) {
        val id = nextId++
        val body = buildJsonObject {
            put("jsonrpc", "2.0"); put("id", id); put("method", method)
            if (params != null) put("params", params)
        }
        post(body).use { resp ->
            val ct = resp.header("Content-Type").orEmpty()
            val msg: JsonObject =
                if (ct.startsWith("text/event-stream")) readSse(resp.body!!.source(), id)
                else Json.parseToJsonElement(resp.body!!.string()).jsonObject
            msg["error"]?.let { throw IllegalStateException("MCP error: $it") }
            msg["result"] ?: JsonNull
        }
    }

    private suspend fun notify(method: String) = withContext(Dispatchers.IO) {
        post(buildJsonObject { put("jsonrpc", "2.0"); put("method", method) }).close()
    }

    private fun post(body: JsonObject): Response {
        val rb = Request.Builder().url(url)
            .post(body.toString().toRequestBody(JSON_MT))
            .header("Accept", "application/json, text/event-stream")
        session?.let { rb.header("Mcp-Session-Id", it) }
        negotiated?.let { rb.header("MCP-Protocol-Version", it) }
        bearer?.takeIf { it.isNotBlank() }?.let { rb.header("Authorization", "Bearer $it") }
        val resp = http.newCall(rb.build()).execute()
        if (!resp.isSuccessful) {
            val code = resp.code; resp.close()
            throw IllegalStateException("HTTP $code from $url")
        }
        resp.header("Mcp-Session-Id")?.let { session = it }
        return resp
    }

    private fun readSse(src: BufferedSource, id: Int): JsonObject {
        val data = StringBuilder()
        while (true) {
            val line = src.readUtf8Line() ?: break
            if (line.startsWith("data:")) {
                data.append(line.removePrefix("data:").trimStart()).append('\n')
            } else if (line.isEmpty() && data.isNotEmpty()) {
                val o = runCatching { Json.parseToJsonElement(data.toString()).jsonObject }.getOrNull()
                data.clear()
                if (o != null && o["id"]?.jsonPrimitive?.intOrNull == id) return o
            }
        }
        throw IllegalStateException("SSE stream ended without a response")
    }
}

/** Several MCP servers behind one tool namespace (first server wins on name clashes). */
class McpHub {
    private val byTool = mutableMapOf<String, McpClient>()
    var tools: List<McpTool> = emptyList(); private set

    suspend fun connect(servers: List<ServerCfg>): List<String> {
        byTool.clear()
        val all = mutableListOf<McpTool>()
        val errors = mutableListOf<String>()
        for (s in servers) try {
            val c = McpClient(s.url, s.token)
            c.connect()
            c.tools.forEach { if (byTool.putIfAbsent(it.name, c) == null) all += it }
        } catch (e: Exception) {
            errors += "${s.url}: ${e.message}"
        }
        tools = all
        return errors
    }

    suspend fun call(name: String, args: JsonObject): String {
        val c = byTool[name] ?: return "ERROR: unknown tool '$name'"
        return try { c.callTool(name, args) } catch (e: Exception) { "ERROR: ${e.message}" }
    }
}
