package dev.localllm

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.*

class UiMsg(val role: String, text: String) { var text by mutableStateOf(text) }

private class ToolCall(val name: String?, val args: JsonObject?, val raw: String)

private val DROP = setOf("\$schema", "title", "additionalProperties", "default", "examples")

/** Shrinks a JSON schema: drops noise keys and truncates descriptions, so the tool list costs fewer tokens. */
private fun slim(e: JsonElement): JsonElement = when (e) {
    is JsonObject -> JsonObject(buildMap<String, JsonElement> {
        for ((k, v) in e) when {
            k in DROP -> {}
            k == "description" && v is JsonPrimitive && v.isString -> put(k, JsonPrimitive(v.content.take(100)))
            k == "properties" && v is JsonObject -> put(k, JsonObject(v.mapValues { slim(it.value) }))
            else -> put(k, slim(v))
        }
    })
    is JsonArray -> JsonArray(e.map { slim(it) })
    else -> e
}

private const val TOOL_BUDGET_CHARS = 6000     // ~1.5k tokens: prefill is the slow part on a phone

private val CALL_RE = Regex("<tool_call>\\s*(.*?)\\s*</tool_call>", RegexOption.DOT_MATCHES_ALL)

private fun parseToolCalls(text: String): List<ToolCall> = CALL_RE.findAll(text).map { m ->
    val raw = m.groupValues[1]
    runCatching {
        val o = Json.parseToJsonElement(raw).jsonObject
        val a = o["arguments"] ?: o["parameters"]
        val args = when (a) {
            is JsonObject -> a
            is JsonPrimitive -> if (a.isString) Json.parseToJsonElement(a.content).jsonObject else JsonObject(emptyMap())
            else -> JsonObject(emptyMap())
        }
        ToolCall(o["name"]!!.jsonPrimitive.content, args, raw)
    }.getOrElse { ToolCall(null, null, raw) }
}.toList()

class ChatViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("cfg", Context.MODE_PRIVATE)
    private val engine = LlamaEngine()
    private val hub = McpHub()
    private var modelFd: ParcelFileDescriptor? = null
    private val history = mutableListOf<Msg>()
    private var sys = ""                       // cached: a byte-stable prefix keeps the KV cache warm
    private var job: Job? = null
    @Volatile private var stopped = false

    val messages = mutableStateListOf<UiMsg>()
    var status by mutableStateOf("No model loaded"); private set
    var busy by mutableStateOf(false); private set
    var modelReady by mutableStateOf(false); private set
    var toolCount by mutableIntStateOf(0); private set
    var toolsSent by mutableIntStateOf(0); private set
    var nCtx by mutableIntStateOf(prefs.getInt("nCtx", 4096))
    var servers by mutableStateOf(
        runCatching { Json.decodeFromString<List<ServerCfg>>(prefs.getString("servers", "[]")!!) }
            .getOrDefault(emptyList())
    ); private set

    init {
        prefs.getString("model", null)?.let { loadModel(Uri.parse(it), persist = false) }
        if (servers.isNotEmpty()) connectServers()
    }

    fun loadModel(uri: Uri, persist: Boolean = true) = viewModelScope.launch {
        status = "Loading model…"; modelReady = false
        val cr = getApplication<Application>().contentResolver
        try {
            if (persist) cr.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            // Load straight from the picked file's fd: no multi-GB copy into app storage.
            val pfd = cr.openFileDescriptor(uri, "r") ?: error("can't open file")
            modelFd?.close(); modelFd = pfd
            val err = engine.load(pfd.fd, nCtx)
            if (err.isNotEmpty()) error(err.trim())
            prefs.edit().putString("model", uri.toString()).putInt("nCtx", nCtx).apply()
            newChat(); modelReady = true; status = "Ready · ctx $nCtx"
        } catch (e: Exception) {
            status = "Load failed: ${e.message}"
        }
    }

    fun saveServers(list: List<ServerCfg>) {
        servers = list
        prefs.edit().putString("servers", Json.encodeToString(list)).apply()
        connectServers()
    }

    private fun connectServers() = viewModelScope.launch {
        val errs = hub.connect(servers)
        toolCount = hub.tools.size
        sys = ""                               // rebuild with the new tool list
        systemPrompt()
        status = if (errs.isNotEmpty()) errs.first() else "MCP: ${hub.tools.size} tools ($toolsSent fit in the prompt)"
    }

    fun newChat() { history.clear(); messages.clear() }
    fun stop() { stopped = true; engine.cancel() }

    private fun systemPrompt(): String {
        if (sys.isNotEmpty()) return sys
        val b = StringBuilder("You are a concise, helpful assistant running fully on-device.")
        if (hub.tools.isNotEmpty()) {
            b.append("\n\n# Tools\n\nYou may call one or more functions to assist with the user query.\n\n")
            b.append("You are provided with function signatures within <tools></tools> XML tags:\n<tools>")
            var used = 0; var sent = 0
            for (t in hub.tools) {
                val line = buildJsonObject {
                    put("type", "function")
                    put("function", buildJsonObject {
                        put("name", t.name)
                        put("description", t.description.take(200))
                        put("parameters", slim(t.schema))
                    })
                }.toString()
                if (used + line.length > TOOL_BUDGET_CHARS) break
                used += line.length; sent++
                b.append('\n').append(line)
            }
            toolsSent = sent
            b.append("\n</tools>\n\nFor each function call, return a json object with function name and arguments ")
            b.append("within <tool_call></tool_call> XML tags:\n<tool_call>\n")
            b.append("{\"name\": <function-name>, \"arguments\": <args-json-object>}\n</tool_call>")
        }
        return b.toString().also { sys = it }
    }

    fun send(text: String) {
        if (busy || !modelReady || text.isBlank()) return
        stopped = false; busy = true
        messages += UiMsg("user", text); history += Msg("user", text)
        job = viewModelScope.launch {
            try {
                var round = 0
                while (round < 6) {            // cap agent loop: model -> tool -> model ...
                    round++
                    val prompt = engine.template(listOf(Msg("system", systemPrompt())) + history)
                    if (prompt.isEmpty()) { status = "This model's chat template isn't supported"; break }

                    val ui = UiMsg("assistant", ""); messages += ui
                    val sb = StringBuilder(); var last = 0L
                    ui.text = "Reading prompt…"
                    val poll = launch {                        // live prefill progress (slow on phones)
                        while (true) {
                            val p = engine.progress()
                            val done = (p shr 32).toInt(); val tot = (p and 0xffffffffL).toInt()
                            if (tot > 0 && done < tot && (ui.text.isEmpty() || ui.text.startsWith("Reading prompt")))
                                ui.text = "Reading prompt… $done / $tot tokens"
                            delay(300)
                        }
                    }
                    val n = try {
                        engine.generate(prompt, 1024, 0.7f) { piece ->
                            sb.append(piece)
                            val now = SystemClock.uptimeMillis()
                            if (now - last > 40) { ui.text = sb.toString(); last = now }   // throttle recomposition
                            !stopped && !sb.contains("</tool_call>")
                        }
                    } finally { poll.cancel() }
                    ui.text = sb.toString()
                    if (n >= 0) status = "Ready · ctx $nCtx · " + engine.stats()
                    if (n >= 0 && sb.isEmpty() && !stopped) {
                        ui.text = "(no output: the model ended its turn immediately, wrong chat template or model?)"
                        break
                    }

                    if (n == -2 && history.size > 2) {         // context full: drop the oldest exchange, retry
                        messages.remove(ui); repeat(2) { history.removeAt(0) }; round--; continue
                    }
                    if (n < 0) { ui.text = "⚠️ " + engine.lastError(); break }

                    history += Msg("assistant", sb.toString())
                    if (stopped) break
                    val calls = parseToolCalls(sb.toString())
                    if (calls.isEmpty()) break

                    val resp = StringBuilder()
                    for (c in calls) {
                        val name = c.name
                        val result = if (name == null) "ERROR: could not parse tool call JSON"
                                     else hub.call(name, c.args ?: JsonObject(emptyMap()))
                        messages += UiMsg("tool", "🔧 ${name ?: "invalid call"}(${c.args ?: c.raw})\n→ ${result.take(600)}")
                        resp.append("<tool_response>\n").append(result).append("\n</tool_response>\n")
                    }
                    history += Msg("user", resp.toString().trimEnd())   // ChatML models expect tool output as a user turn
                }
            } finally {
                busy = false
            }
        }
    }

    override fun onCleared() { engine.cancel(); modelFd?.close() }
}
